
### WARNING
MAU RE-UPLOAD SCRIPT? KASIH NAMA/LINK CHANEL SAYA.... DILARANG UBAH INFO!!!

## NOTE:> 
SCRIPTNYA JANGAN DI JUAL/BELI KAN.. SCRIPT INI 100% GRATIS BUAT KALIAN PENGGUNA TERMUX
</div>

### ALAT DAN BAHAN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### CARA INSTALLNYA  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/hmm.gif" width="29px">
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage [ Lalu Ijinkan ]
> apt-get update -y
> apt-get upgrade -y
> pkg install git -y
> pkg install bash -y
> pkg install mc -y
> git clone https://github.com/Y0kenz4su/yzbot
> cd yzbot
> bash install.sh
> npm start
> SCAN DAH BRO MHEHE EZ KAN:V
```


